﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DBConnection;
using System.Configuration;
using System.Diagnostics;

namespace Controller.DAL
{
    public class Initializer
    {
        #region variable Declaration

        static string _ConnectionString = string.Empty;
        static SQL _sql = new SQL();
        #endregion

        #region Constructors

        #endregion

        #region Accessors

        #endregion

        #region Mutators
        /// <summary>
        /// This method will create the database on the specified SQL Server. 
        /// </summary>
        public static void CreateDatabase()
        {
            _ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            //call the SQL CreateDatabase method to build the database in SQL server
            _sql.CreateDatabase(_ConnectionString);
            CreateDatabaseTables();
            //  SeedDataBaseTables();
        }

        private static void SeedDataBaseTables()
        {
            SeedCentre();
            SeedDepartment();
            SeedReason();
            SeedRequest();
            SeedRetailer();
            SeedRetailerRequest();
            SeedStore();
            SeedUserAccount();
            SeedWStaff();
            SeedRetailerStore();

        }

        private static void SeedCentre()
        {
            List<string> centres = new List<string>
            {
                "1, 'Carindale'",
                "2, 'Chermside'",
                "3, 'Northlakes'"
                
            };

            //columnNames must match the order of the test data above
            string columnNames = "CentreID, CentreName";

            //loop through the list movies and push the data to the database table
            foreach (var centre in centres)
            {
                _sql.InsertRecord(_ConnectionString, "Centre", columnNames, centre);
            }
        }

        private static void SeedDepartment()
        {
            List<string> departments = new List<string>
            {
                "1, 'Concierge'",
                "2, 'Valet'",
                "3, 'Carpark'",
                "4, 'CMO'"

            };

            //columnNames must match the order of the test data above
            string columnNames = "DeptID, DeptName";

            //loop through the list movies and push the data to the database table
            foreach (var department in departments)
            {
                _sql.InsertRecord(_ConnectionString, "Department", columnNames, department);
            }
        }

        private static void SeedReason()
        {
            List<string> reasons = new List<string>
            {
                "1, 'Malfunctioning Staff Card'",
                "2, 'Lost Ticket'",
                "3, 'I dont want to pay!'", 
                "4, 'Other' "

            };

            //columnNames must match the order of the test data above
            string columnNames = "ReasonID, Reason";

            //loop through the list movies and push the data to the database table
            foreach (var reason in reasons)
            {
                _sql.InsertRecord(_ConnectionString, "Reason", columnNames, reason);
            }
        }


        private static void SeedWStaff()
        {
            List<string> wStaffs = new List<string>
            {
                "1, 'John Smith', 1, 1",
                "2, 'Mary Parks', 2, 2",
                "3, 'Robert Boyd', 3, 3",
                "4, 'Jenny Arthy', 4, 1 "
            };

            //columnNames must match the order of the test data above
            string columnNames = "WStaffID, StaffName, DeptID, CentreID";

            //loop through the list movies and push the data to the database table
            foreach (var wStaff in wStaffs)
            {
                _sql.InsertRecord(_ConnectionString, "WStaff", columnNames, wStaff);
            }
        }

        private static void SeedUserAccount()
        {
            List<string> userAccounts = new List<string>
            {
                "1, 'JohnSmith', 'Password1', 1 ",
                "2, 'MaryParks', 'Password2', 2 ",
                "3, 'RobertBoyd','Password3', 3 ",
                "4, 'JennyArthy','Password4', 4 "
            };

            //columnNames must match the order of the test data above
            string columnNames = "UserID, UserName, UserPassword, StaffID";

            //loop through the list movies and push the data to the database table
            foreach (var userAccount in userAccounts)
            {
                _sql.InsertRecord(_ConnectionString, "UserAccount", columnNames, userAccount);
            }
        }

        private static void SeedStore()
        {
            // create a list of workShop data
            List<string> stores = new List<string>
            {
                "1, 'Apple', 1, '' ",
                "2, 'Big W', 1, '' ",
                "3, 'Kikki K', 1, '' ",
                "4, 'DJI', 1, '' ",
                "5, 'Other', 1, 'BrandSpace' "
            };
            #region another way of creating lists

            #endregion

            //columnNames must match the order of the test data above
            string columnNames = "StoreID, StoreName, CentreID, Comment";

            //loop through the list movies and push the data to the database table
            foreach (var store in stores)
            {
                _sql.InsertRecord(_ConnectionString, "Store", columnNames, store);
            }
        }

        private static void SeedRetailerStore()
        {
            // create a list of workShop data
            List<string> retailerStores = new List<string>
            {
                "1, 1, 1 ",
                "2, 2, 2 ",
                "3, 3, 3 ",
                "4, 4, 5 ",
                
            };
            #region another way of creating lists

            #endregion

            //columnNames must match the order of the test data above
            string columnNames = "RetailerStoreID, StoreID, RetailerID";

            //loop through the list movies and push the data to the database table
            foreach (var retailerstore in retailerStores)
            {
                _sql.InsertRecord(_ConnectionString, "RetailerStore", columnNames, retailerstore);
            }
        }
        private static void SeedRetailer()
        {
            // create a list of Brand data
            List<string> retailers = new List<string>
            {
                "1, 'Reef Bentley', '123ABC', '' ",
                "2, 'Stanley Blah', '234BCD', '432DCB' ",
                "3, 'Ryobi Nakamura', '345CDE', '' ",
                "4, 'Jaymi James', '456DEF', '' ",
                "5, 'Joshua Overson', '567EFG', '765GFE' "
            };
        

            //columnNames must match the order of the test data above
            string columnNames = "RetailerID, RetailerName, Registration, Comment";

            //loop through the list movies and push the data to the database table
            foreach (var retailer in retailers)
            {
                _sql.InsertRecord(_ConnectionString, "Retailer", columnNames, retailer);
            }
        }

        private static void SeedRetailerRequest()
        {
            List<string> retailerRequests = new List<string>
            {
                "1, 2, 1 ",
                "2, 3, 2 ",
                "3, 4, 3 ",
                "4, 1, 4 "
            };

            //columnNames must match the order of the test data above
            string columnNames = "RetailerRequestID, RetailerID, RequestID";

            //loop through the list movies and push the data to the database table
            foreach (var retailerRequest in retailerRequests)
            {
                _sql.InsertRecord(_ConnectionString, "RetailerRequest", columnNames, retailerRequest);
            }
        }

        private static void SeedRequest()
        {
            List<string> requests = new List<string>
            {
                "1, 2, '432DCB', '2020/03/09', 1, '', 2 ",
                "2, 3, '345CDE', '2020/03/10', 2, '', 3 ",
                "3, 4, '456DEF', '2020/03/10', 3, '', 3 ",
                "4, 5, '567EFG', '2020/03/10', 4, 'blah', 1 "
            };

            //columnNames must match the order of the test data above
            string columnNames = "RequestID, StoreID, Registration, RequestDate, ReasonID, Comment, UserID";

            //loop through the list movies and push the data to the database table
            foreach (var request in requests )
            {
                _sql.InsertRecord(_ConnectionString, "Request", columnNames, request);
            }
        }

        private static void CreateDatabaseTables()
        {
            //Centre table schema
            string CentreSchema = "CentreID int IDENTITY(1,1) PRIMARY KEY, " +
                                  "CentreName VARCHAR(50) NOT NULL";

            //Customer table schema
            string DepartmentSchema = "DeptID int IDENTITY(1,1) PRIMARY KEY, " +
                                    "DeptName VARCHAR(50) NOT NULL";


            //Rental table schema
            string ReasonSchema = "ReasonID int IDENTITY(1,1) PRIMARY KEY, " +
                                  "Reason VARCHAR(50) NOT NULL";


            //rental item table schema
            string RequestSchema = "RequestID int IDENTITY(1,1) PRIMARY KEY, " +
                                       "StoreID int NOT NULL, " +
                                       "Registration VARCHAR(10) NOT NULL, " +
                                       "RequestDate DATETIME NOT NULL, " +
                                       "ReasonID int NOT NULL, " +
                                       "Comment VARCHAR(255), " +
                                       "UserID int NOT NULL";
            //workShop table schema
            string RetailerSchema = "RetailerID int IDENTITY(1,1) PRIMARY KEY, " +
                                    "RetailerName VARCHAR(50) NOT NULL, " +
                                    "Registration VARCHAR(10) NOT NULL, " +
                                    "Comment VARCHAR(255)";

            //Brand table schema
            string RetailerRequestSchema = "RetailerRequestID int IDENTITY(1,1) PRIMARY KEY, " +
                                           "RetailerID int NOT NULL, " +
                                           "RequestID int NOT NULL";

            //RetailerStore schema
            string RetailerStoreSchema = "RetailerStoreID int IDENTITY(1,1) PRIMARY KEY, " +
                                         "StoreID int NOT NULL, " +
                                         "RetailerID int NOT NULL";

            //Store schema
            string StoreSchema = "StoreID int IDENTITY(1,1) PRIMARY KEY, " +
                                 "StoreName VARCHAR(50) NOT NULL, " +
                                 "CentreID int NOT NULL, " +
                                 "Comment VARCHAR(255)";

            //UserAccount Schema
            string UserAccountSchema = "UserID int IDENTITY(1,1) PRIMARY KEY, " +
                                       "UserName VARCHAR(50) NOT NULL, " +
                                       "UserPassword VARCHAR(50) NOT NULL, " +
                                       "StaffID int NOT NULL";

            //WStaff Schema
            string WStaffSchema = "StaffID int IDENTITY(1,1) PRIMARY KEY, " +
                                  "StaffName VARCHAR(50) NOT NULL, " +
                                  "DeptID int NOT NULL, " +
                                  "CentreID int NOT NULL";

         

            //create the Tool table
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "Centre", CentreSchema);
                SeedCentre();
            }
            catch
            {
                Debug.WriteLine("Seeding of Centre Table skipped as it already exists");
            }

            //create the customer table
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "Department", DepartmentSchema);
                SeedDepartment();

            }
            catch
            {
                Debug.WriteLine("Seeding of Department Table skipped as it already exists");
            }

            //create the rental table 
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "Reason", ReasonSchema);
                SeedReason();

            }
            catch
            {
                Debug.WriteLine("Seeding of Reason Table skipped as it already exists");
            }

            //create the rental item table
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "Request", RequestSchema);
                SeedRequest();

            }
            catch
            {
                Debug.WriteLine("Seeding of Request Table skipped as it already exists");
            }

            //create the workShop Schema
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "Retailer", RetailerSchema);
                SeedRetailer();
            }
            catch
            {
                Debug.WriteLine("Seeding of Retailer Table skipped as it already exists");
            }

            //create the Brand Schema
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "RetailerRequest", RetailerRequestSchema);
                SeedRetailerRequest();
            }
            catch
            {
                Debug.WriteLine("Seeding of RetailerRequest Table skipped as it already exists");
            }

            //create the Brand Schema
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "RetailerStore", RetailerStoreSchema);
                SeedRetailerStore();
            }
            catch
            {
                Debug.WriteLine("Seeding of RetailerStore Table skipped as it already exists");
            }

            //create the Brand Schema
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "Store", StoreSchema);
                SeedStore();
            }
            catch
            {
                Debug.WriteLine("Seeding of Store Table skipped as it already exists");
            }

            //create the Brand Schema
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "UserAccount",UserAccountSchema);
                SeedUserAccount();
            }
            catch
            {
                Debug.WriteLine("Seeding of UserAccount Table skipped as it already exists");
            }

            //create the Brand Schema
            try
            {
                _sql.CreateDatabaseTable(_ConnectionString, "WStaff", WStaffSchema);
                SeedWStaff();
            }
            catch
            {
                Debug.WriteLine("Seeding of WStaff Table skipped as it already exists");
            }
        }
    }




    #endregion
}

