﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DBConnection;
using System.Configuration;
using System.Data;


namespace Controller.DAL
{
    public static class Context
    {
        #region variable Declaration

        static SQL _sql = new SQL();

        #endregion

        #region Constructors

        #endregion

        #region Accessors

        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            }
        }
        /// <summary>
        /// this method will return all records from the specified database table.
        /// </summary>
        /// <param name="tableName"></the database table name where the records will come from.>
        /// <returns></returns>
        public static DataTable GetDataTable(string tableName)
        {
            return _sql.GetDataTable(ConnectionString, tableName);
        }

        /// <summary>
        ///  this method will return the recods based on the specified  SQL query
        /// </summary>
        /// <param name="sqlQuery"></the SELECT query that will be used to filte the records>
        /// <param name="tableName"></the database table name where the records will come from.>
        /// <returns></returns>
        public static DataTable GetDataTable(string sqlQuery, string tableName)
        {
            return _sql.GetDataTable(ConnectionString, sqlQuery, tableName);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlQuery"></the SELECT query that will be used to filte the records>
        /// <param name="tableName"></the database table name where the records will come from>
        /// <param name="isReadOnly"></to indicate whether the returned datavese table is updateable or not.>
        /// <returns></returns>
        public static DataTable GetDataTable(string sqlQuery, string tableName, bool isReadOnly)
        {
            return _sql.GetDataTable(ConnectionString, sqlQuery, tableName, isReadOnly);
        }

        #endregion

        #region Mutators
        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        public static void SaveDatabaseTable(DataTable table)
        {
            _sql.SaveDatabaseTable(ConnectionString, table);
        }

        public static int InsertParentTable(string tableName, string columnName, string columnValues)
        {
            return _sql.InsertParentRecord(ConnectionString, tableName, columnName, columnValues);
        }

        public static void DeleteRecord(string tableName, string PKname, string PKID)
        {
            _sql.DeleteRecord(ConnectionString, tableName, PKname, PKID);
        }
        #endregion

        #region Helper Methods

        #endregion
    }
}



