﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmAdminMenu : Form
    {
        #region Constructors
        public frmAdminMenu()
        {
            InitializeComponent();
        }

        #endregion

        #region Button Events
        private void BtnReports_Click(object sender, EventArgs e)
        {
            frmReports frm = new frmReports();
            frm.ShowDialog();
        }

        private void BtnAddStore_Click(object sender, EventArgs e)
        {
            frmStore frm = new frmStore();
            frm.ShowDialog();
        }

        private void BtnAddCentre_Click(object sender, EventArgs e)
        {
            frmAddCentre frm = new frmAddCentre();
            frm.ShowDialog();
        }

        private void BtnAddDept_Click(object sender, EventArgs e)
        {
            frmDepartment frm = new frmDepartment();
            frm.ShowDialog();
        }

        private void BtnAddReason_Click(object sender, EventArgs e)
        {
            frmReason frm = new frmReason();
            frm.ShowDialog();
        }

        private void BtnWTeam_Click(object sender, EventArgs e)
        {
            frmWStaff frm = new frmWStaff();
            frm.ShowDialog();
        }

        private void BtnAdminRetailers_Click(object sender, EventArgs e)
        {
            frmAddRetailer frm = new frmAddRetailer();
            frm.ShowDialog();
        }

        #endregion
    }
}
