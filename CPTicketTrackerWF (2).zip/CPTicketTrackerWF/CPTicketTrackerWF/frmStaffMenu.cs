﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmStaffMenu : Form
    {
        public frmStaffMenu()
        {
            InitializeComponent();
        }

        private void BtnRetailerSearch_Click(object sender, EventArgs e)
        {
            frmRetailerSearch frm = new frmRetailerSearch();
            frm.ShowDialog();
        }

        private void FrmStaffMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
