﻿using Controller.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmNewRequest : Form
    {
        #region Variable Declaration
        long _PKID = 0, _RetailerRequestID = 0;
        DataTable _dtbRequests = null;
        bool _isNew = false;

        #endregion

        #region Constructors
        public frmNewRequest(string RetailerRequestID)
        {
            _isNew = true;
            _RetailerRequestID = long.Parse(RetailerRequestID);
            InitializeComponent();
            InitializeDataTable();
        }

        public frmNewRequest(long pKID)
        {
            InitializeComponent();
            _PKID = pKID;
            InitializeDataTable();
        }

        #endregion

        #region Mutators

        private void InitializeDataTable()
        {
            string sql = $"SELECT * FROM Request WHERE RequestID = {_PKID}";
            _dtbRequests = Context.GetDataTable(sql, "Request");

            if (_isNew)
            {
                DataRow row = _dtbRequests.NewRow();
                _dtbRequests.Rows.Add(row);
            }
        }

        #endregion

        #region Helper Methods

        private void PopulateComboBox()
        {
                                        
            //DataTable dtb = new DataTable();
            DataTable dtb = Context.GetDataTable("Reason");
            DataTable dtbs = Context.GetDataTable("Store");

            cboReason.ValueMember = "ReasonID";
            cboStore.ValueMember = "StoreID";

            cboStore.DisplayMember = "StoreName";
            cboReason.DisplayMember = "Reason";

            cboStore.DataSource = dtbs;
            cboReason.DataSource = dtb;


        }

        private void BindControls()
        {
            txtRetailerRequestID.DataBindings.Add("Text", _dtbRequests, "RetailerRequestID");
            cboReason.DataBindings.Add("SelectedValue", _dtbRequests, "ReasonID");
            cboStore.DataBindings.Add("SelectedValue", _dtbRequests, "StoreID");

        }

        #endregion

        #region form events

        private void FrmNewRequest_Load(object sender, EventArgs e)
        {
            PopulateComboBox();
            BindControls();
            if (_isNew)
            {
                txtRetailerRequestID.Text = _RetailerRequestID.ToString();
            }
        }

        #endregion

        #region Button Events
        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (_isNew)
            {
                txtRetailerRequestID.Focus();
                txtRetailerRequestID.Text = _RetailerRequestID.ToString();
                btnSave.Focus();
            }

            _dtbRequests.Rows[0].EndEdit();
            Context.SaveDatabaseTable(_dtbRequests);
        }

        #endregion
    }
}
