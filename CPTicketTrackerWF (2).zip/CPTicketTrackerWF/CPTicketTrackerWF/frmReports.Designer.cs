﻿namespace CPTicketTrackerWF
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnByReason = new System.Windows.Forms.Button();
            this.btnByDate = new System.Windows.Forms.Button();
            this.btnByStore = new System.Windows.Forms.Button();
            this.btnByRetailer = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnByUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnByReason
            // 
            this.btnByReason.Location = new System.Drawing.Point(134, 163);
            this.btnByReason.Name = "btnByReason";
            this.btnByReason.Size = new System.Drawing.Size(250, 62);
            this.btnByReason.TabIndex = 24;
            this.btnByReason.Text = "Ticket Request Frequency By Reason For Ticket";
            this.btnByReason.UseVisualStyleBackColor = true;
            this.btnByReason.Click += new System.EventHandler(this.BtnByReason_Click);
            // 
            // btnByDate
            // 
            this.btnByDate.Location = new System.Drawing.Point(134, 231);
            this.btnByDate.Name = "btnByDate";
            this.btnByDate.Size = new System.Drawing.Size(250, 62);
            this.btnByDate.TabIndex = 26;
            this.btnByDate.Text = "Ticket Requests By Date";
            this.btnByDate.UseVisualStyleBackColor = true;
            this.btnByDate.Click += new System.EventHandler(this.BtnByDate_Click);
            // 
            // btnByStore
            // 
            this.btnByStore.Location = new System.Drawing.Point(134, 93);
            this.btnByStore.Name = "btnByStore";
            this.btnByStore.Size = new System.Drawing.Size(250, 64);
            this.btnByStore.TabIndex = 27;
            this.btnByStore.Text = "Ticket Request Frequency By Store";
            this.btnByStore.UseVisualStyleBackColor = true;
            this.btnByStore.Click += new System.EventHandler(this.BtnByStore_Click);
            // 
            // btnByRetailer
            // 
            this.btnByRetailer.Location = new System.Drawing.Point(134, 12);
            this.btnByRetailer.Name = "btnByRetailer";
            this.btnByRetailer.Size = new System.Drawing.Size(250, 75);
            this.btnByRetailer.TabIndex = 28;
            this.btnByRetailer.Text = "Ticket Requests Frequency By Retailer";
            this.btnByRetailer.UseVisualStyleBackColor = true;
            this.btnByRetailer.Click += new System.EventHandler(this.BtnByRetailer_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(192, 386);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(130, 45);
            this.btnBack.TabIndex = 29;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // btnByUser
            // 
            this.btnByUser.Location = new System.Drawing.Point(134, 299);
            this.btnByUser.Name = "btnByUser";
            this.btnByUser.Size = new System.Drawing.Size(250, 75);
            this.btnByUser.TabIndex = 30;
            this.btnByUser.Text = "Ticket Requests By Westfield Staff Member";
            this.btnByUser.UseVisualStyleBackColor = true;
            this.btnByUser.Click += new System.EventHandler(this.BtnByUser_Click);
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 450);
            this.Controls.Add(this.btnByUser);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnByRetailer);
            this.Controls.Add(this.btnByStore);
            this.Controls.Add(this.btnByDate);
            this.Controls.Add(this.btnByReason);
            this.Name = "frmReports";
            this.Text = "frmReports";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnByReason;
        private System.Windows.Forms.Button btnByDate;
        private System.Windows.Forms.Button btnByStore;
        private System.Windows.Forms.Button btnByRetailer;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnByUser;
    }
}