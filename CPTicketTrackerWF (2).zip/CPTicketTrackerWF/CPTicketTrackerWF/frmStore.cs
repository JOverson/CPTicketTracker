﻿using Controller.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmStore : Form
    {
        #region Constructors
        public frmStore()
        {
            InitializeComponent();
        }

        #endregion

        #region Button Events

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this item?", "Store",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    long PKID = long.Parse(dgvStores[0, dgvStores.CurrentCell.RowIndex]
                                    .Value.ToString());

                    Context.DeleteRecord("Store", "StoreID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record exists", "Customer");
                }
            }
        }

        #endregion

        #region Form Events
        private void FrmStore_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion

        #region Helper Methods

        private void PopulateGrid()
        {
            DataTable dtb = new DataTable();
            dtb = Context.GetDataTable("Store");
            dgvStores.DataSource = dtb;
        }

        #endregion


    }
}
