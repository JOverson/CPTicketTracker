﻿namespace CPTicketTrackerWF
{
    partial class frmAddRetailer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRetailerName = new System.Windows.Forms.TextBox();
            this.txtRegistration = new System.Windows.Forms.TextBox();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.dgvRetailerStores = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnDeleteStore = new System.Windows.Forms.Button();
            this.btnAddStore = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnDeleteRequest = new System.Windows.Forms.Button();
            this.btnAddRequest = new System.Windows.Forms.Button();
            this.dgvRequests = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRetailerStores)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(6, 502);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(130, 54);
            this.btnBack.TabIndex = 12;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(812, 502);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(121, 54);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Save ";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(76, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 23);
            this.label1.TabIndex = 14;
            this.label1.Text = "Vehicle Registration:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(76, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 23);
            this.label3.TabIndex = 16;
            this.label3.Text = "Retailer Name: ";
            // 
            // txtRetailerName
            // 
            this.txtRetailerName.Location = new System.Drawing.Point(237, 14);
            this.txtRetailerName.Name = "txtRetailerName";
            this.txtRetailerName.Size = new System.Drawing.Size(155, 22);
            this.txtRetailerName.TabIndex = 17;
            // 
            // txtRegistration
            // 
            this.txtRegistration.Location = new System.Drawing.Point(237, 42);
            this.txtRegistration.Name = "txtRegistration";
            this.txtRegistration.Size = new System.Drawing.Size(155, 22);
            this.txtRegistration.TabIndex = 19;
            // 
            // txtComment
            // 
            this.txtComment.Location = new System.Drawing.Point(6, 109);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(503, 121);
            this.txtComment.TabIndex = 20;
            // 
            // dgvRetailerStores
            // 
            this.dgvRetailerStores.AllowUserToAddRows = false;
            this.dgvRetailerStores.AllowUserToDeleteRows = false;
            this.dgvRetailerStores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRetailerStores.Location = new System.Drawing.Point(-1, -1);
            this.dgvRetailerStores.Name = "dgvRetailerStores";
            this.dgvRetailerStores.ReadOnly = true;
            this.dgvRetailerStores.RowHeadersWidth = 51;
            this.dgvRetailerStores.RowTemplate.Height = 24;
            this.dgvRetailerStores.Size = new System.Drawing.Size(398, 172);
            this.dgvRetailerStores.TabIndex = 21;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnDeleteStore);
            this.panel1.Controls.Add(this.btnAddStore);
            this.panel1.Controls.Add(this.dgvRetailerStores);
            this.panel1.Location = new System.Drawing.Point(515, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(398, 227);
            this.panel1.TabIndex = 22;
            // 
            // btnDeleteStore
            // 
            this.btnDeleteStore.Location = new System.Drawing.Point(139, 177);
            this.btnDeleteStore.Name = "btnDeleteStore";
            this.btnDeleteStore.Size = new System.Drawing.Size(130, 45);
            this.btnDeleteStore.TabIndex = 24;
            this.btnDeleteStore.Text = "Delete Store";
            this.btnDeleteStore.UseVisualStyleBackColor = true;
            this.btnDeleteStore.Click += new System.EventHandler(this.BtnDeleteStore_Click);
            // 
            // btnAddStore
            // 
            this.btnAddStore.Location = new System.Drawing.Point(3, 177);
            this.btnAddStore.Name = "btnAddStore";
            this.btnAddStore.Size = new System.Drawing.Size(130, 45);
            this.btnAddStore.TabIndex = 23;
            this.btnAddStore.Text = "Add Store";
            this.btnAddStore.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(3, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 23);
            this.label4.TabIndex = 23;
            this.label4.Text = "Comment";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.txtComment);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtRetailerName);
            this.panel2.Controls.Add(this.txtRegistration);
            this.panel2.Location = new System.Drawing.Point(6, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(927, 248);
            this.panel2.TabIndex = 25;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnDeleteRequest);
            this.panel3.Controls.Add(this.btnAddRequest);
            this.panel3.Controls.Add(this.dgvRequests);
            this.panel3.Location = new System.Drawing.Point(6, 266);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(927, 230);
            this.panel3.TabIndex = 26;
            // 
            // btnDeleteRequest
            // 
            this.btnDeleteRequest.Location = new System.Drawing.Point(142, 180);
            this.btnDeleteRequest.Name = "btnDeleteRequest";
            this.btnDeleteRequest.Size = new System.Drawing.Size(130, 45);
            this.btnDeleteRequest.TabIndex = 25;
            this.btnDeleteRequest.Text = "Delete Request";
            this.btnDeleteRequest.UseVisualStyleBackColor = true;
            this.btnDeleteRequest.Click += new System.EventHandler(this.BtnDeleteRequest_Click);
            // 
            // btnAddRequest
            // 
            this.btnAddRequest.Location = new System.Drawing.Point(6, 180);
            this.btnAddRequest.Name = "btnAddRequest";
            this.btnAddRequest.Size = new System.Drawing.Size(130, 45);
            this.btnAddRequest.TabIndex = 24;
            this.btnAddRequest.Text = "Add New Request";
            this.btnAddRequest.UseVisualStyleBackColor = true;
            // 
            // dgvRequests
            // 
            this.dgvRequests.AllowUserToAddRows = false;
            this.dgvRequests.AllowUserToDeleteRows = false;
            this.dgvRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequests.Location = new System.Drawing.Point(0, -1);
            this.dgvRequests.Name = "dgvRequests";
            this.dgvRequests.ReadOnly = true;
            this.dgvRequests.RowHeadersWidth = 51;
            this.dgvRequests.RowTemplate.Height = 24;
            this.dgvRequests.Size = new System.Drawing.Size(927, 175);
            this.dgvRequests.TabIndex = 0;
            // 
            // frmAddRetailer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 568);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnSave);
            this.Name = "frmAddRetailer";
            this.Text = "frmAddRetailer";
            ((System.ComponentModel.ISupportInitialize)(this.dgvRetailerStores)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequests)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRetailerName;
        private System.Windows.Forms.TextBox txtRegistration;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.DataGridView dgvRetailerStores;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAddStore;
        private System.Windows.Forms.Button btnDeleteStore;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDeleteRequest;
        private System.Windows.Forms.Button btnAddRequest;
        private System.Windows.Forms.DataGridView dgvRequests;
    }
}