﻿using Controller.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmAddCentre : Form
    {
        #region Constructors
        public frmAddCentre()
        {
            InitializeComponent();
        }

        #endregion

        #region Button Events
        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this item?", "Centre",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    long PKID = long.Parse(dgvCentres[0, dgvCentres.CurrentCell.RowIndex]
                                    .Value.ToString());

                    Context.DeleteRecord("Centre", "CentreID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record exists", "Centre");
                }
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Form Events
        private void FrmAddCentre_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion

        #region Helper Methods

        private void PopulateGrid()
        {
            DataTable dtb = new DataTable();
            dtb = Context.GetDataTable("Centre");
            dgvCentres.DataSource = dtb;
        }

        #endregion

    }
}
