﻿using Controller.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmReason : Form
    {
        #region Constructors
        public frmReason()
        {
            InitializeComponent();
        }

        #endregion

        #region Button Events
        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this item?", "Reason",
    MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    long PKID = long.Parse(dgvReasons[0, dgvReasons.CurrentCell.RowIndex]
                                    .Value.ToString());

                    Context.DeleteRecord("Reason", "ReasonID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record exists", "Reason");
                }
            }
        }



        #endregion

        #region Form Events
        private void FrmReason_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion

        #region Helper Methods

        private void PopulateGrid()
        {
            DataTable dtb = new DataTable();
            dtb = Context.GetDataTable("Reason");
            dgvReasons.DataSource = dtb;
        }
        #endregion

        // Ask Alan what is different, now that we are creating
        // new and editing existing entries in the DGV, rather
        // than a different screen! 
        // How to make it save? Bind Controls like in frmTool?!
    }
}
