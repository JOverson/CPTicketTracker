﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controller.DAL;

namespace CPTicketTrackerWF
{
    public partial class frmAddRetailer : Form
    {
        #region Variable Declaration

        long _PKID = 0;
        DataTable _retailerRequestTable = null, _retailerStore = null;
        bool _isNew = false;

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnDeleteRequest_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this item?", "Request",
    MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    long PKID = long.Parse(dgvRequests[0, dgvRequests.CurrentCell.RowIndex]
                                    .Value.ToString());

                    Context.DeleteRecord("Request", "RequestID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record exists", "Request");
                }
            }
        }

        private void BtnDeleteStore_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this item?", "RetailerStore",
    MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    long PKID = long.Parse(dgvRetailerStores[0, dgvRetailerStores.CurrentCell.RowIndex]
                                    .Value.ToString());

                    Context.DeleteRecord("RetailerStore", "RetailerStoreID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record exists", "RetailerStore");
                }
            }
        }

        #endregion

        #region Constructors
        public frmAddRetailer()
        {
            InitializeComponent();
            _isNew = true;
            InitializeDataTable();
        }

        public frmAddRetailer(long PKID)
        {
            InitializeComponent();
            _PKID = pKID;
            InitializeDataTable();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {

        }

        // private void BtnSave_Click(object sender, EventArgs e)
        // {

        // }

        #endregion

        #region Button Events

        #endregion

        #region Helper Methods

        private void InitializeDataTable()
        {
            _retailerRequestTable = Context.GetDataTable($"SELECT * FROM Request WHERE RequestID = {_PKID}", "Request");
            PopulateGrid();
        }

        #endregion
    }
}
