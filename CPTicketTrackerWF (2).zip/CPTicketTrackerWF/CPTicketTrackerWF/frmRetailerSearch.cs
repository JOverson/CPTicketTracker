﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controller.DAL;


namespace CPTicketTrackerWF
{
    public partial class frmRetailerSearch : Form
    {
        #region Constructors
        public frmRetailerSearch()
        {
            InitializeComponent();
        }

        #endregion

        #region Button Events

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

              

        private void BtnAddNewRetailer_Click(object sender, EventArgs e)
        {
            frmAddRetailer frm = new frmAddRetailer();
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this item?", "AddRetailer",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    long PKID = long.Parse(dgvRetailers[0, dgvRetailers.CurrentCell.RowIndex]
                                    .Value.ToString());

                    Context.DeleteRecord("Retailer", "RetailerID", PKID.ToString());
                    PopulateGrid();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No Record exists", "Retailer");
                }
            }
        }
        #endregion

        #region Form Events
        private void FrmRetailerSearch_Load(object sender, EventArgs e)
        {
            PopulateGrid();
        }

        #endregion

        #region Helper Methods
        private void PopulateGrid()
        {
            DataTable dtb = new DataTable();
            dtb = Context.GetDataTable("Retailer");
            dgvRetailers.DataSource = dtb;
        }

        private void DgvRetailers_DoubleClick(object sender, EventArgs e)
        {
            if (dgvRetailers.CurrentCell == null) return;

            long PKID = long.Parse(dgvRetailers[0, dgvRetailers.CurrentCell.RowIndex].Value.ToString());

            frmAddRetailer frm = new frmAddRetailer(PKID);
            if (frm.ShowDialog() == DialogResult.OK)
                PopulateGrid();
        }

        #endregion
    }
}
