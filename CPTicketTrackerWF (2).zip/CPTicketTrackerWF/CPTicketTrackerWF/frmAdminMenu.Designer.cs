﻿namespace CPTicketTrackerWF
{
    partial class frmAdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnWTeam = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnAddReason = new System.Windows.Forms.Button();
            this.btnAddStore = new System.Windows.Forms.Button();
            this.btnAddDept = new System.Windows.Forms.Button();
            this.btnAddCentre = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnAdminRetailers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnWTeam
            // 
            this.btnWTeam.Location = new System.Drawing.Point(147, 122);
            this.btnWTeam.Name = "btnWTeam";
            this.btnWTeam.Size = new System.Drawing.Size(245, 79);
            this.btnWTeam.TabIndex = 2;
            this.btnWTeam.Text = "Add / Edit Westfield Team Member";
            this.btnWTeam.UseVisualStyleBackColor = true;
            this.btnWTeam.Click += new System.EventHandler(this.BtnWTeam_Click);
            // 
            // btnReports
            // 
            this.btnReports.Location = new System.Drawing.Point(398, 122);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(260, 79);
            this.btnReports.TabIndex = 3;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = true;
            this.btnReports.Click += new System.EventHandler(this.BtnReports_Click);
            // 
            // btnAddReason
            // 
            this.btnAddReason.Location = new System.Drawing.Point(177, 233);
            this.btnAddReason.Name = "btnAddReason";
            this.btnAddReason.Size = new System.Drawing.Size(215, 75);
            this.btnAddReason.TabIndex = 4;
            this.btnAddReason.Text = "Add / Edit Reason for Request";
            this.btnAddReason.UseVisualStyleBackColor = true;
            this.btnAddReason.Click += new System.EventHandler(this.BtnAddReason_Click);
            // 
            // btnAddStore
            // 
            this.btnAddStore.Location = new System.Drawing.Point(398, 233);
            this.btnAddStore.Name = "btnAddStore";
            this.btnAddStore.Size = new System.Drawing.Size(229, 75);
            this.btnAddStore.TabIndex = 5;
            this.btnAddStore.Text = "Add / Edit Stores";
            this.btnAddStore.UseVisualStyleBackColor = true;
            this.btnAddStore.Click += new System.EventHandler(this.BtnAddStore_Click);
            // 
            // btnAddDept
            // 
            this.btnAddDept.Location = new System.Drawing.Point(177, 314);
            this.btnAddDept.Name = "btnAddDept";
            this.btnAddDept.Size = new System.Drawing.Size(215, 75);
            this.btnAddDept.TabIndex = 6;
            this.btnAddDept.Text = "Add / Edit Westfield Departments";
            this.btnAddDept.UseVisualStyleBackColor = true;
            this.btnAddDept.Click += new System.EventHandler(this.BtnAddDept_Click);
            // 
            // btnAddCentre
            // 
            this.btnAddCentre.Location = new System.Drawing.Point(398, 314);
            this.btnAddCentre.Name = "btnAddCentre";
            this.btnAddCentre.Size = new System.Drawing.Size(229, 75);
            this.btnAddCentre.TabIndex = 7;
            this.btnAddCentre.Text = "Add / Edit Centres";
            this.btnAddCentre.UseVisualStyleBackColor = true;
            this.btnAddCentre.Click += new System.EventHandler(this.BtnAddCentre_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(658, 510);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(130, 54);
            this.btnLogOut.TabIndex = 8;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            // 
            // btnAdminRetailers
            // 
            this.btnAdminRetailers.Location = new System.Drawing.Point(278, 395);
            this.btnAdminRetailers.Name = "btnAdminRetailers";
            this.btnAdminRetailers.Size = new System.Drawing.Size(224, 79);
            this.btnAdminRetailers.TabIndex = 9;
            this.btnAdminRetailers.Text = "Add / Edit Retailer";
            this.btnAdminRetailers.UseVisualStyleBackColor = true;
            this.btnAdminRetailers.Click += new System.EventHandler(this.BtnAdminRetailers_Click);
            // 
            // frmAdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 576);
            this.Controls.Add(this.btnAdminRetailers);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnAddCentre);
            this.Controls.Add(this.btnAddDept);
            this.Controls.Add(this.btnAddStore);
            this.Controls.Add(this.btnAddReason);
            this.Controls.Add(this.btnReports);
            this.Controls.Add(this.btnWTeam);
            this.Name = "frmAdminMenu";
            this.Text = "frmAdminMenu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnWTeam;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnAddReason;
        private System.Windows.Forms.Button btnAddStore;
        private System.Windows.Forms.Button btnAddDept;
        private System.Windows.Forms.Button btnAddCentre;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnAdminRetailers;
    }
}