﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CPTicketTrackerWF
{
    public partial class frmReports : Form
    {
        #region Constructors
        public frmReports()
        {
            InitializeComponent();
        }



        #endregion

        #region Button Events

        private void BtnByRetailer_Click(object sender, EventArgs e)
        {
            frmByRetailer frm = new frmByRetailer();
            frm.ShowDialog();
        }

        private void BtnByStore_Click(object sender, EventArgs e)
        {
            frmByStore frm = new frmByStore();
            frm.ShowDialog();
        }

        private void BtnByReason_Click(object sender, EventArgs e)
        {
            frmByReason frm = new frmByReason();
            frm.ShowDialog();
        }

        private void BtnByDate_Click(object sender, EventArgs e)
        {
            frmByDate frm = new frmByDate();
            frm.ShowDialog();
        }

        private void BtnByUser_Click(object sender, EventArgs e)
        {
            frmByUser frm = new frmByUser();
            frm.ShowDialog();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion
    }
}
